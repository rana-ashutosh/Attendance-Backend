const express = require('express');
const { clockIn } = require('../controllers/AttentdenceController');

const router = express.Router();

router.post('/clock-in/:userId', clockIn);

module.exports = router;