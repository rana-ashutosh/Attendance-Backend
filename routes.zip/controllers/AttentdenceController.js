// controllers/attendanceController.js
const Attendance = require("../models/Attendance");
const moment = require('moment');

// Get today's date in YYYY-MM-DD format
const getTodayDate = () => moment().startOf('day').toDate();

const clockIn = async (req, res) => {
  try {
    const { userId } = req.params.userId;
    console.log("===", req.params.userId)
    const today = getTodayDate();
    const existing = await Attendance.findOne({ userId, date: today });
    if (existing) return res.status(400).json({ message: 'Already clocked in' });

    const attendance = new Attendance({
      userId,
      date: today,
      clockIn: new Date(),
      breaks: []
    });

    const result = await attendance.save();
    console.log("==", result)
    res.status(201).json(result);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { clockIn };
